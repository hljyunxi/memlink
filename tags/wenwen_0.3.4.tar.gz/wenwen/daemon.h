#ifndef MEMLINK_DAEMON_H
#define MEMLINK_DAEMON_H

#include <stdio.h>

int daemonize(int nochdir, int noclose);

#endif

