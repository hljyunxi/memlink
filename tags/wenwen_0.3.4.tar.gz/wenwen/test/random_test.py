#!/usr/bin/python
# coding: utf-8
import os, sys
import time, random

def test():
    return 0


if __name__ == '__main__':
    sys.exit(test())


